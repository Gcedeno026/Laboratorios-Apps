package com.example.mynotes.util

object Constants {

    const val DESCRIPTION_TEXT = "This is where your note will be. It’ll be housed here. You’ll save your note here. Type your memories here. Write down your thoughts."
}