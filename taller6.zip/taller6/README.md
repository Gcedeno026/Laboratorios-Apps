# Aplicación Android - Bingo

## Capturas de Pantalla
![Pantalla Inicio](img/1-Inicio.png)
![Pantalla Inicio (input)](img/2-Inicio.png)
![Pantalla Bingo 1](img/3-Bingo.png)
![Pantalla Bingo 2](img/4-Bingo.png)
![Pantalla Bingo 3](img/5-Bingo.png)
