package com.example.taller5

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.border
import java.util.*

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var language: Locale = Locale("es", "ES")
    private var selectedVoice: String = "Masculino"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var textToRead by remember { mutableStateOf("") }
            var languageOption by remember { mutableStateOf(language) }
            var voicesOption by remember { mutableStateOf(selectedVoice) }

            tts = TextToSpeech(this, OnInitListener { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val langResult = tts?.setLanguage(languageOption)
                    if (langResult != TextToSpeech.LANG_AVAILABLE) {
                        // Handle error setting language
                    }
                }
            })

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Taller5 - Text to Speech") }
                    )
                },
                content = {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Caja de texto envuelta en Box con padding
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color.Gray)  // Aplicando borde correctamen
